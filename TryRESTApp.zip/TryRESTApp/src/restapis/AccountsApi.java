package restapis;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.sql.*;

@Path("/banking")
public class AccountsApi {
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Accounts> getAccounts()
	{
		List<Accounts> lst=new ArrayList<Accounts>();
		Accounts ac;
		
		Connection con;
		Statement st;
		ResultSet rs;

		try
		{
		Class.forName("com.mysql.cj.jdbc.Driver");

		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flipkartdb?user=root&password=volkswagen");

		st=con.createStatement();
		rs=st.executeQuery("select * from accounts;");

		while(rs.next())
		{
			ac=new Accounts();
			ac.setAccno(rs.getInt("accno"));
		ac.setAccnm(rs.getString("accnm"));
		ac.setAcctype(rs.getString("acctype"));
		ac.setBalance(rs.getDouble("balance"));
		lst.add(ac);
		}

		con.close();
		}
		catch(Exception e)
		{
		System.out.println(e);
		}

				
		
		return(lst);
	}

}
